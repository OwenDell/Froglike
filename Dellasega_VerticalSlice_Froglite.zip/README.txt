Launching the game: Double click on "Froglite.exe" inside the game folder. All necessary files are inside the .zip

Controls:
* WASD/Arrow Keys to move
* Space to jump
* Left shift to dash
* E to open inventory
* Left Click to grapple an object
* Left Click + Q to drag an object towards you
* Hold Right click to charge a bubble, release to fire it, aimed at your cursor

Known issues:
* Upgrades do not carry over between scenes!
* Movement is too slippery (haha like a frog) we need more friction!
* No models
* No animations
* Some UI
* Very little content, currently only demo and tutorial level.
* Only upgrade type is bubbles 
* Tongue is not implemented, currently just telekinetic frog.
* Moving barrels feels too heavy
* No alligator that eats player when they fall in water.
* Upgrades that should change UI currently do not (extra bubble/dash charges)
* Some UI missing

Design Decisions:
* We designed the gameplay to encourage fast movement to keep the player engaged.
* The way we designed our code was to perform the desired function with as little bloat as possible, however that didn't work as well as we wanted
* The style choices were to both give a cartoonish style while keeping the visuals easy to make.